<template>
  <header class="row-flex justify-sb">
    <h1>{{ title }}</h1>
    <Button :text="'Add task'" :color="'green'" />
  </header>
</template>

<script>
import Button from "./Button.vue";
export default {
  name: "Header",
  props: {
    title: {
      type: String,
      default: "Hello",
    },
  },
  components: {
    Button,
  }, // if you don't pass a prop it will take the default prop
};
</script>

<style scoped>
/* header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
} */
</style>

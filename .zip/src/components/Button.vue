<template>
  <button
    @click="onClick()"
    :style="{ background: color, color: ' white ' }"
    class="btn"
  >
    {{ text }}
  </button>
</template>

<script>
export default {
  name: "Button",
  props: {
    text: { type: String, default: "Add" },
    color: { type: String, default: "red" },
  },
  methods: {
    onClick() {
      console.log("here");
    },
  },
};
</script>

<style scoped>
.btn {
  border: none;
  cursor: pointer;
}
</style>

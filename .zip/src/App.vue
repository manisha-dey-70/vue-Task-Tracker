<template>
  <div class="container">
    <Header :title="'Task Tracker'" />
    <Tasks :tasks="tasks" />
  </div>
</template>

<script>
import Header from "./components/Header.vue";
import Tasks from "./components/Tasks.vue";
export default {
  name: "App",
  components: { Header, Tasks },
  data() {
    return { tasks: [] };
  },
  created() {
    this.tasks = [
      {
        id: 1,
        text: "Doctor's Appointment",
        day: "March 1st at 2:30pm",
        reminder: true,
      },
      {
        id: 2,
        text: "Meet Mira at Sanfe cafe",
        day: "March 21st at 12:30pm",
        reminder: false,
      },
      {
        id: 3,
        text: "Call the plumber",
        day: "April 2nd at 8:30am",
        reminder: false,
      },
      {
        id: 4,
        text: "Submit project report",
        day: "Sept 3rd at 10:00am",
        reminder: true,
      },
    ];
  },
};
</script>

<style>
#app {
  /* font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale; */
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
.container {
  border: 1px solid black;
  font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
  padding: 20px;
}
.justify-center {
  justify-content: center;
}
.justify-sb {
  justify-content: space-between;
}
.row-flex {
  display: flex;
}
.col-flex {
  display: flex;
  flex-direction: column;
}
.align-center {
  align-items: center;
}
</style>

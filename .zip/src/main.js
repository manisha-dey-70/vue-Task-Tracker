import { createApp } from "vue";
import App from "./App.vue";

Vue.config.productionTip = false;
createApp(App).mount("#app");
